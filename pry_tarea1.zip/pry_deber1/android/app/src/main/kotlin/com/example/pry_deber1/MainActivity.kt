package com.example.pry_deber1

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
