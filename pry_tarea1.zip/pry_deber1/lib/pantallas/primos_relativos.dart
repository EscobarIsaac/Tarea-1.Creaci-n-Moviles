import 'package:flutter/material.dart';

class PrimosRelativos extends StatefulWidget {
  @override
  _PrimosRelativosState createState() => _PrimosRelativosState();
}

class _PrimosRelativosState extends State<PrimosRelativos> {
  final TextEditingController aController = TextEditingController();
  final TextEditingController bController = TextEditingController();
  String resultado = '';

  int mcd(int a, int b) => b == 0 ? a : mcd(b, a % b);

  void verificar() {
    int a = int.tryParse(aController.text) ?? 0;
    int b = int.tryParse(bController.text) ?? 0;
    setState(() {
      resultado = mcd(a, b) == 1 ? 'Son primos relativos' : 'No lo son';
    });
  }

  void reiniciar() {
    setState(() {
      aController.clear(); // Limpiar el campo de texto de A
      bController.clear(); // Limpiar el campo de texto de B
      resultado = ''; // Limpiar el resultado
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Primos Relativos')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(controller: aController, decoration: InputDecoration(labelText: 'Número A')),
            TextField(controller: bController, decoration: InputDecoration(labelText: 'Número B')),
            SizedBox(height: 20),
            ElevatedButton(onPressed: verificar, child: Text('Verificar')),
            SizedBox(height: 20),
            Text(resultado),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: reiniciar, // Llamar a la función de reiniciar
              child: Text('Reiniciar'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Volver'),
            ),
          ],
        ),
      ),
    );
  }
}
