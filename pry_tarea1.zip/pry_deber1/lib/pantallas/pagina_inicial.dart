import 'package:flutter/material.dart';
import 'package:pry_deber1/pantallas/primos_relativos.dart';
import 'package:pry_deber1/pantallas/suma_serie_alternante.dart';

class PaginaInicial extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Trabajo 1 Aplicaciones Moviles')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/estadisticas');
              },
              child: Text('Estadísticas de 10 Números'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/abundante');
              },
              child: Text('Número Abundante'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PrimosRelativos()),
                );
              },
              child: Text('Primos Relativos'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SumaSerieAlternante()),
                );
              },
              child: Text('Suma Serie Alternante'),
            ),
          ],
        ),
      ),
    );
  }
}