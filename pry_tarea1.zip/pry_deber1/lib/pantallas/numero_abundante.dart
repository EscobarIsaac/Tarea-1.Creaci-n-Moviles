import 'package:flutter/material.dart';

class NumeroAbundante extends StatefulWidget {
  @override
  _NumeroAbundanteState createState() => _NumeroAbundanteState();
}

class _NumeroAbundanteState extends State<NumeroAbundante> {
  final TextEditingController controller = TextEditingController();
  String resultado = '';

  void verificar() {
    int n = int.tryParse(controller.text) ?? 0;
    int suma = 0;
    for (int i = 1; i < n; i++) {
      if (n % i == 0) suma += i;
    }
    setState(() {
      resultado = suma > n ? 'Es abundante' : 'No es abundante';
    });
  }

  void reiniciar() {
    setState(() {
      controller.clear(); // Limpiar el campo de texto
      resultado = ''; // Limpiar el resultado
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Número Abundante')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Número'),
            ),
            SizedBox(height: 20),
            ElevatedButton(onPressed: verificar, child: Text('Verificar')),
            SizedBox(height: 20),
            Text(resultado),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: reiniciar, // Llamar a la función reiniciar
              child: Text('Reiniciar'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Volver'),
            ),
          ],
        ),
      ),
    );
  }
}
