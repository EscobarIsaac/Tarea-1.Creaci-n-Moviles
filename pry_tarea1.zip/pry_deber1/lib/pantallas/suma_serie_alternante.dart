import 'package:flutter/material.dart';

class SumaSerieAlternante extends StatefulWidget {
  @override
  _SumaSerieAlternanteState createState() => _SumaSerieAlternanteState();
}

class _SumaSerieAlternanteState extends State<SumaSerieAlternante> {
  final TextEditingController controller = TextEditingController();
  String resultado = '';

  void calcular() {
    int n = int.tryParse(controller.text) ?? 0;
    int suma = 0;
    List<int> elementos = [];

    for (int i = 1; i <= n; i++) {
      int termino;
      if (i % 2 == 1) {
        termino = 1 + 2 * ((i - 1) ~/ 2); // 1, 3, 5, ...
      } else {
        termino = 5 + 2 * ((i - 2) ~/ 2); // 5, 7, 9, ...
      }
      suma += termino;
      elementos.add(termino);
    }

    setState(() {
      resultado = 'Los primeros $n términos son:\n${elementos.join(', ')}\n\nSuma: $suma';
    });
  }

  void reiniciar() {
    setState(() {
      controller.clear(); // Limpiar el campo de texto
      resultado = ''; // Limpiar el resultado
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Suma Alternante')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(controller: controller, decoration: InputDecoration(labelText: 'Cantidad de términos')),
            SizedBox(height: 20),
            ElevatedButton(onPressed: calcular, child: Text('Calcular')),
            SizedBox(height: 20),
            Text(resultado),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: reiniciar, // Llamar a la función reiniciar
              child: Text('Reiniciar'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Volver'),
            ),
          ],
        ),
      ),
    );
  }
}
