import 'package:flutter/material.dart';
import 'dart:math';

class EstadisticasDiezNumeros extends StatefulWidget {
  @override
  _EstadisticasDiezNumerosState createState() => _EstadisticasDiezNumerosState();
}

class _EstadisticasDiezNumerosState extends State<EstadisticasDiezNumeros> {
  final List<TextEditingController> controllers =
  List.generate(10, (_) => TextEditingController());
  String resultado = '';

  void calcular() {
    List<double> numeros = controllers.map((c) => double.tryParse(c.text) ?? 0).toList();
    double promedio = numeros.reduce((a, b) => a + b) / numeros.length;
    double maximo = numeros.reduce(max);
    double minimo = numeros.reduce(min);
    double mediana = () {
      List<double> ordenados = List.from(numeros)..sort();
      return (ordenados[4] + ordenados[5]) / 2;
    }();

    setState(() {
      resultado = 'Promedio: $promedio\nMáximo: $maximo\nMínimo: $minimo\nMediana: $mediana';
    });
  }

  void reiniciar() {
    setState(() {
      // Limpiar todos los campos
      for (var controller in controllers) {
        controller.clear();
      }
      resultado = ''; // Limpiar el resultado
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Estadísticas')),
      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            ...List.generate(10, (i) => TextField(
              controller: controllers[i],
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: 'Número ${i + 1}'),
            )),
            SizedBox(height: 20),
            ElevatedButton(onPressed: calcular, child: Text('Calcular')),
            SizedBox(height: 20),
            Text(resultado),
            ElevatedButton(
              onPressed: reiniciar, // Llama a la función de reinicio
              child: Text('Reiniciar'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Volver'),
            ),
          ],
        ),
      ),
    );
  }
}
