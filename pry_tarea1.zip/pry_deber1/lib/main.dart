import 'package:flutter/material.dart';
import 'package:pry_deber1/pantallas/pagina_inicial.dart';
import 'package:pry_deber1/pantallas/estadisticas_diez_numeros.dart';
import 'package:pry_deber1/pantallas/numero_abundante.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    initialRoute: '/',
    routes: {
      '/': (context) => PaginaInicial(),
      '/estadisticas': (context) => EstadisticasDiezNumeros(),
      '/abundante': (context) => NumeroAbundante(),
    },
  ));
}
